
Copyright 2014-2021 Grafana Labs

This software is based on Kibana: 
Copyright 2012-2013 Elasticsearch BV

